# Bounded MarkDuplicates evidence

adversarial synthetic whole MarkDuplicates commands; not WGS/cohort evidence

ordered full alignment fields and tags excluding PG; SQ/RG headers with explicit-zone RG dates compared as exact instants; normalized DuplicationMetrics tables and numeric histograms (bounded-v4; not charts)

All cases completed: True; required candidate checks: True

| Case | Baseline seconds | Candidate seconds | Picard seconds | Baseline RSS bytes | Candidate RSS bytes | Candidate parity |
|---|---:|---:|---:|---:|---:|---|
| coordinate-ties-unplaced | 0.181403 | 0.170576 | 3.321617 | 42061824 | 42315776 | True |
| same-name-same-library | 0.163499 | 0.151999 | 3.344843 | 41840640 | 41975808 | True |
| same-name-separate-libraries | 0.166457 | 0.152730 | 3.389172 | 41996288 | 41971712 | True |
| optical-and-barcodes | 0.155133 | 0.149335 | 3.625225 | 42029056 | 42123264 | True |
| remove-optical | 0.160435 | 0.149248 | 3.475434 | 41951232 | 42131456 | True |
| remove-all | 0.179716 | 0.170558 | 3.233006 | 42020864 | 42270720 | True |
| large-duplicate-family | 0.270564 | 0.265741 | 3.372833 | 72994816 | 74493952 | True |
| spill-600k | 1.247169 | 1.222615 | 4.612448 | 170393600 | 169967616 | True |
| spill-1200k | 2.455405 | 2.354335 | 5.714959 | 170393600 | 169988096 | True |
| paired-600k | 2.809099 | 2.294674 | 5.693383 | 287588352 | 251031552 | True |
| paired-spill-1200k | 5.448341 | 4.585706 | 7.488291 | 288776192 | 264298496 | True |

One warm-up and three measured repetitions. Alternating order, one-CPU affinity, native HTS workers disabled, Java heap 2 GiB. Warm-cache shared runner; not WGS or universal superiority evidence. Failed baseline cases remain in raw JSON and are not speedup claims.
